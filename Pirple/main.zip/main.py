#Favorite movie

Title = "Star Wars: A New Hope"
Director = "George Lucas"
Duration = 121
'''
The duration is in minutes
'''
Year = 1977
Takings= 775.385 
'''
Takings refer to Collection 
Because collection is a keyword
Collection is in USD or United States Dollars
'''
Language = "English"
Genre = "Space Opera"

print(Title)
print(type(Title))
print(Director)
print(type(Director))
print(Duration)
print(type(Duration))
print(Year)
print(type(Year))
print(Takings)
print(type(Takings))
print(Language)
print(type(Language))
print(Genre)
print(type(Genre))



